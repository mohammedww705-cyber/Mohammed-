import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:photo_view/photo_view.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'dart:io';
import '../models/file_item.dart';
import '../theme/app_theme.dart';

class FileViewerScreen extends StatelessWidget {
  final FileItem file;
  const FileViewerScreen({super.key, required this.file});

  @override
  Widget build(BuildContext context) {
    switch (file.category) {
      case FileCategory.pdf:
        return _PdfViewer(file: file);
      case FileCategory.images:
        return _ImageViewer(file: file);
      case FileCategory.videos:
        return _VideoViewer(file: file);
      default:
        return _TextViewer(file: file);
    }
  }
}

// ─── PDF Viewer ───────────────────────────────────────────────────────────────
class _PdfViewer extends StatefulWidget {
  final FileItem file;
  const _PdfViewer({required this.file});
  @override
  State<_PdfViewer> createState() => _PdfViewerState();
}

class _PdfViewerState extends State<_PdfViewer> {
  int _totalPages = 0;
  int _currentPage = 0;
  PDFViewController? _controller;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(widget.file.name, style: const TextStyle(color: AppColors.text1, fontSize: 14, fontWeight: FontWeight.w600), maxLines: 1, overflow: TextOverflow.ellipsis),
          if (_totalPages > 0) Text('صفحة ${_currentPage + 1} من $_totalPages', style: const TextStyle(color: AppColors.text3, fontSize: 11)),
        ]),
        actions: [
          IconButton(icon: const Icon(Icons.share_rounded, color: AppColors.text2), onPressed: () {}),
        ],
      ),
      body: PDFView(
        filePath: widget.file.path,
        enableSwipe: true,
        swipeHorizontal: false,
        autoSpacing: true,
        pageFling: true,
        onRender: (pages) => setState(() => _totalPages = pages ?? 0),
        onPageChanged: (page, _) => setState(() => _currentPage = page ?? 0),
        onViewCreated: (ctrl) => _controller = ctrl,
      ),
      bottomNavigationBar: _totalPages > 0
          ? Container(
              color: AppColors.surface,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Row(children: [
                IconButton(
                  icon: const Icon(Icons.chevron_left_rounded, color: AppColors.text2),
                  onPressed: _currentPage > 0 ? () => _controller?.setPage(_currentPage - 1) : null,
                ),
                Expanded(child: SliderTheme(
                  data: SliderTheme.of(context).copyWith(activeTrackColor: AppColors.accent, thumbColor: AppColors.accent, inactiveTrackColor: AppColors.surface3),
                  child: Slider(
                    value: _currentPage.toDouble(),
                    min: 0, max: (_totalPages - 1).toDouble(),
                    onChanged: (v) => _controller?.setPage(v.toInt()),
                  ),
                )),
                IconButton(
                  icon: const Icon(Icons.chevron_right_rounded, color: AppColors.text2),
                  onPressed: _currentPage < _totalPages - 1 ? () => _controller?.setPage(_currentPage + 1) : null,
                ),
              ]),
            )
          : null,
    );
  }
}

// ─── Image Viewer ─────────────────────────────────────────────────────────────
class _ImageViewer extends StatelessWidget {
  final FileItem file;
  const _ImageViewer({required this.file});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black.withOpacity(0.5),
        title: Text(file.name, style: const TextStyle(color: Colors.white, fontSize: 14), maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(icon: const Icon(Icons.share_rounded, color: Colors.white), onPressed: () {}),
          IconButton(icon: const Icon(Icons.info_outline_rounded, color: Colors.white), onPressed: () => _showInfo(context)),
        ],
      ),
      body: PhotoView(
        imageProvider: FileImage(File(file.path)),
        minScale: PhotoViewComputedScale.contained,
        maxScale: PhotoViewComputedScale.covered * 4,
        backgroundDecoration: const BoxDecoration(color: Colors.black),
        loadingBuilder: (_, __) => const Center(child: CircularProgressIndicator(color: AppColors.accent)),
      ),
    );
  }

  void _showInfo(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface2,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('معلومات الملف', style: TextStyle(color: AppColors.text1, fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(height: 16),
          _InfoRow('الاسم', file.name),
          _InfoRow('الحجم', file.formattedSize),
          _InfoRow('التاريخ', file.modified.toString().split('.').first),
          _InfoRow('المسار', file.path),
        ]),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label, value;
  const _InfoRow(this.label, this.value);
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(children: [
        SizedBox(width: 70, child: Text(label, style: const TextStyle(color: AppColors.text3, fontSize: 12))),
        Expanded(child: Text(value, style: const TextStyle(color: AppColors.text1, fontSize: 12), overflow: TextOverflow.ellipsis)),
      ]),
    );
  }
}

// ─── Video Viewer ─────────────────────────────────────────────────────────────
class _VideoViewer extends StatefulWidget {
  final FileItem file;
  const _VideoViewer({required this.file});
  @override
  State<_VideoViewer> createState() => _VideoViewerState();
}

class _VideoViewerState extends State<_VideoViewer> {
  VideoPlayerController? _vpCtrl;
  ChewieController? _chewieCtrl;

  @override
  void initState() {
    super.initState();
    _initVideo();
  }

  Future<void> _initVideo() async {
    _vpCtrl = VideoPlayerController.file(File(widget.file.path));
    await _vpCtrl!.initialize();
    _chewieCtrl = ChewieController(
      videoPlayerController: _vpCtrl!,
      autoPlay: true,
      looping: false,
      allowFullScreen: true,
      materialProgressColors: ChewieProgressColors(
        playedColor: AppColors.accent,
        handleColor: AppColors.accent,
        bufferedColor: AppColors.surface3,
        backgroundColor: AppColors.surface,
      ),
    );
    setState(() {});
  }

  @override
  void dispose() {
    _vpCtrl?.dispose();
    _chewieCtrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(widget.file.name, style: const TextStyle(color: Colors.white, fontSize: 14), maxLines: 1, overflow: TextOverflow.ellipsis),
      ),
      body: Center(
        child: _chewieCtrl != null
            ? Chewie(controller: _chewieCtrl!)
            : const CircularProgressIndicator(color: AppColors.accent),
      ),
    );
  }
}

// ─── Text Viewer ──────────────────────────────────────────────────────────────
class _TextViewer extends StatefulWidget {
  final FileItem file;
  const _TextViewer({required this.file});
  @override
  State<_TextViewer> createState() => _TextViewerState();
}

class _TextViewerState extends State<_TextViewer> {
  String _content = '';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadContent();
  }

  Future<void> _loadContent() async {
    try {
      final content = await File(widget.file.path).readAsString();
      setState(() { _content = content; _loading = false; });
    } catch (e) {
      setState(() { _content = 'لا يمكن قراءة هذا الملف\n\n$e'; _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        title: Text(widget.file.name, style: const TextStyle(color: AppColors.text1, fontSize: 14), maxLines: 1, overflow: TextOverflow.ellipsis),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.accent))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Text(_content, style: const TextStyle(color: AppColors.text1, fontSize: 13, height: 1.6, fontFamily: 'monospace')),
            ),
    );
  }
}
